var DSPjs = require('./dsp.js');

console.log(DSPjs);

